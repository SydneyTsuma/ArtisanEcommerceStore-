import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Artisan Market</h1>
          <p className="text-xl text-gray-600">Choose your dashboard to get started</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="text-orange-600">Artisan Dashboard</CardTitle>
              <CardDescription>Manage your products, view orders, and track your business</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/artisan">
                <Button className="w-full bg-orange-600 hover:bg-orange-700">Access Artisan Dashboard</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="text-blue-600">Buyer Dashboard</CardTitle>
              <CardDescription>Manage your profile, leave reviews, and track purchases</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/buyer">
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Access Buyer Dashboard</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="text-purple-600">Admin Dashboard</CardTitle>
              <CardDescription>Manage users, moderate content, and oversee platform</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/admin">
                <Button className="w-full bg-purple-600 hover:bg-purple-700">Access Admin Dashboard</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
