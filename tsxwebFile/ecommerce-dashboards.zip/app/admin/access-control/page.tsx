"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Shield, Ban, UserCheck, Search, AlertTriangle } from "lucide-react"

export default function AccessControlPage() {
  const [users, setUsers] = useState([
    {
      id: 1,
      name: "Sarah Johnson",
      email: "sarah@crafts.com",
      role: "Artisan",
      status: "Active",
      permissions: ["sell", "message"],
    },
    {
      id: 2,
      name: "Alice Brown",
      email: "alice@email.com",
      role: "Buyer",
      status: "Active",
      permissions: ["buy", "review"],
    },
    {
      id: 3,
      name: "Mike Chen",
      email: "mike@pottery.com",
      role: "Artisan",
      status: "Restricted",
      permissions: ["sell"],
    },
    { id: 4, name: "Emma Davis", email: "emma@leather.com", role: "Artisan", status: "Suspended", permissions: [] },
  ])

  const [searchTerm, setSearchTerm] = useState("")

  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const toggleUserStatus = (userId: number, newStatus: string) => {
    setUsers(users.map((user) => (user.id === userId ? { ...user, status: newStatus } : user)))
  }

  const updatePermissions = (userId: number, permission: string, enabled: boolean) => {
    setUsers(
      users.map((user) => {
        if (user.id === userId) {
          const newPermissions = enabled
            ? [...user.permissions, permission]
            : user.permissions.filter((p) => p !== permission)
          return { ...user, permissions: newPermissions }
        }
        return user
      }),
    )
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Access Control</h1>
          <p className="text-gray-600 mt-2">Manage user permissions and access levels</p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-purple-600 hover:bg-purple-700">
              <Shield className="h-4 w-4 mr-2" />
              Manage Permissions
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Bulk Permission Management</DialogTitle>
              <DialogDescription>Apply permission changes to multiple users</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>User Role</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="artisan">Artisan</SelectItem>
                    <SelectItem value="buyer">Buyer</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Action</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select action" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="activate">Activate All</SelectItem>
                    <SelectItem value="restrict">Restrict All</SelectItem>
                    <SelectItem value="suspend">Suspend All</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button className="w-full">Apply Changes</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Users</CardTitle>
            <UserCheck className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{users.filter((u) => u.status === "Active").length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Restricted Users</CardTitle>
            <AlertTriangle className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {users.filter((u) => u.status === "Restricted").length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Suspended Users</CardTitle>
            <Ban className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {users.filter((u) => u.status === "Suspended").length}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>User Access Management</CardTitle>
              <CardDescription>Control user permissions and account status</CardDescription>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search users..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Permissions</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div>
                      <p className="font-medium">{user.name}</p>
                      <p className="text-sm text-gray-600">{user.email}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={user.role === "Artisan" ? "default" : "secondary"}>{user.role}</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        user.status === "Active"
                          ? "default"
                          : user.status === "Restricted"
                            ? "secondary"
                            : "destructive"
                      }
                    >
                      {user.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-2">
                      {user.role === "Artisan" && (
                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={user.permissions.includes("sell")}
                            onCheckedChange={(checked) => updatePermissions(user.id, "sell", checked)}
                          />
                          <Label className="text-sm">Sell Products</Label>
                        </div>
                      )}
                      {user.role === "Buyer" && (
                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={user.permissions.includes("buy")}
                            onCheckedChange={(checked) => updatePermissions(user.id, "buy", checked)}
                          />
                          <Label className="text-sm">Make Purchases</Label>
                        </div>
                      )}
                      <div className="flex items-center space-x-2">
                        <Switch
                          checked={user.permissions.includes("message")}
                          onCheckedChange={(checked) => updatePermissions(user.id, "message", checked)}
                        />
                        <Label className="text-sm">Send Messages</Label>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      {user.status !== "Active" && (
                        <Button variant="outline" size="sm" onClick={() => toggleUserStatus(user.id, "Active")}>
                          <UserCheck className="h-4 w-4" />
                        </Button>
                      )}
                      {user.status !== "Restricted" && (
                        <Button variant="outline" size="sm" onClick={() => toggleUserStatus(user.id, "Restricted")}>
                          <AlertTriangle className="h-4 w-4" />
                        </Button>
                      )}
                      {user.status !== "Suspended" && (
                        <Button variant="outline" size="sm" onClick={() => toggleUserStatus(user.id, "Suspended")}>
                          <Ban className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
