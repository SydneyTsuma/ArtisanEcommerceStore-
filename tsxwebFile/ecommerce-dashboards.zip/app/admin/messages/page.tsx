"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MessageSquare, Send, User, Package } from "lucide-react"

export default function MessagesPage() {
  const [selectedUser, setSelectedUser] = useState("")
  const [messageContent, setMessageContent] = useState("")

  const artisans = [
    { id: 1, name: "Sarah Johnson", email: "sarah@crafts.com", status: "Active", products: 12 },
    { id: 2, name: "Mike Chen", email: "mike@pottery.com", status: "Active", products: 8 },
    { id: 3, name: "Emma Davis", email: "emma@leather.com", status: "Suspended", products: 15 },
  ]

  const buyers = [
    { id: 1, name: "Alice Brown", email: "alice@email.com", status: "Active", orders: 23 },
    { id: 2, name: "David Wilson", email: "david@email.com", status: "Active", orders: 12 },
    { id: 3, name: "Lisa Garcia", email: "lisa@email.com", status: "Active", orders: 8 },
  ]

  const conversations = [
    {
      id: 1,
      user: "Sarah Johnson",
      type: "Artisan",
      lastMessage: "Thank you for the help!",
      time: "2 hours ago",
      unread: false,
    },
    {
      id: 2,
      user: "Alice Brown",
      type: "Buyer",
      lastMessage: "I have a question about my order",
      time: "4 hours ago",
      unread: true,
    },
    {
      id: 3,
      user: "Mike Chen",
      type: "Artisan",
      lastMessage: "Product approval needed",
      time: "1 day ago",
      unread: true,
    },
  ]

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Messages</h1>
          <p className="text-gray-600 mt-2">Direct messaging with artisans and buyers</p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-purple-600 hover:bg-purple-700">
              <Send className="h-4 w-4 mr-2" />
              New Message
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Send New Message</DialogTitle>
              <DialogDescription>Send a direct message to an artisan or buyer</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="recipient">Recipient</Label>
                <Select value={selectedUser} onValueChange={setSelectedUser}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a user" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="artisan-header" disabled>
                      Artisans
                    </SelectItem>
                    {artisans.map((artisan) => (
                      <SelectItem key={`artisan-${artisan.id}`} value={`artisan-${artisan.id}`}>
                        {artisan.name} ({artisan.email})
                      </SelectItem>
                    ))}
                    <SelectItem value="buyer-header" disabled>
                      Buyers
                    </SelectItem>
                    {buyers.map((buyer) => (
                      <SelectItem key={`buyer-${buyer.id}`} value={`buyer-${buyer.id}`}>
                        {buyer.name} ({buyer.email})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="subject">Subject</Label>
                <Input id="subject" placeholder="Message subject" />
              </div>
              <div>
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  value={messageContent}
                  onChange={(e) => setMessageContent(e.target.value)}
                  placeholder="Type your message here..."
                  className="min-h-[100px]"
                />
              </div>
              <Button className="w-full">Send Message</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="conversations" className="space-y-6">
        <TabsList>
          <TabsTrigger value="conversations">Conversations</TabsTrigger>
          <TabsTrigger value="artisans">Artisans</TabsTrigger>
          <TabsTrigger value="buyers">Buyers</TabsTrigger>
        </TabsList>

        <TabsContent value="conversations">
          <Card>
            <CardHeader>
              <CardTitle>Recent Conversations</CardTitle>
              <CardDescription>Active message threads with users</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {conversations.map((conversation) => (
                  <div
                    key={conversation.id}
                    className="flex items-center justify-between p-4 bg-white rounded-lg border hover:shadow-sm transition-shadow"
                  >
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 bg-gray-200 rounded-full flex items-center justify-center">
                        {conversation.type === "Artisan" ? (
                          <Package className="h-5 w-5 text-gray-600" />
                        ) : (
                          <User className="h-5 w-5 text-gray-600" />
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{conversation.user}</p>
                          <Badge variant={conversation.type === "Artisan" ? "default" : "secondary"}>
                            {conversation.type}
                          </Badge>
                          {conversation.unread && (
                            <Badge variant="destructive" className="text-xs">
                              New
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-600">{conversation.lastMessage}</p>
                        <p className="text-xs text-gray-500">{conversation.time}</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Reply
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="artisans">
          <Card>
            <CardHeader>
              <CardTitle>Artisan Directory</CardTitle>
              <CardDescription>Send messages to artisans</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {artisans.map((artisan) => (
                  <div key={artisan.id} className="flex items-center justify-between p-4 bg-white rounded-lg border">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 bg-orange-100 rounded-full flex items-center justify-center">
                        <Package className="h-5 w-5 text-orange-600" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{artisan.name}</p>
                          <Badge variant={artisan.status === "Active" ? "default" : "destructive"}>
                            {artisan.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600">{artisan.email}</p>
                        <p className="text-xs text-gray-500">{artisan.products} products</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Message
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="buyers">
          <Card>
            <CardHeader>
              <CardTitle>Buyer Directory</CardTitle>
              <CardDescription>Send messages to buyers</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {buyers.map((buyer) => (
                  <div key={buyer.id} className="flex items-center justify-between p-4 bg-white rounded-lg border">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <User className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{buyer.name}</p>
                          <Badge variant={buyer.status === "Active" ? "default" : "destructive"}>{buyer.status}</Badge>
                        </div>
                        <p className="text-sm text-gray-600">{buyer.email}</p>
                        <p className="text-xs text-gray-500">{buyer.orders} orders</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Message
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
