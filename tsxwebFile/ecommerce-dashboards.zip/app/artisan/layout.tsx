import type React from "react"
import { SidebarProvider } from "@/components/ui/sidebar"
import { ArtisanSidebar } from "@/components/artisan-sidebar"

export default function ArtisanLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <ArtisanSidebar />
        <main className="flex-1 bg-gray-50">{children}</main>
      </div>
    </SidebarProvider>
  )
}
