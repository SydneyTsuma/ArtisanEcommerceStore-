import type React from "react"
import { SidebarProvider } from "@/components/ui/sidebar"
import { BuyerSidebar } from "@/components/buyer-sidebar"

export default function BuyerLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <BuyerSidebar />
        <main className="flex-1 bg-gray-50">{children}</main>
      </div>
    </SidebarProvider>
  )
}
