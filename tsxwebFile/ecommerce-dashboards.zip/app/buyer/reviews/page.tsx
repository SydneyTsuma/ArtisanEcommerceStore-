"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Star, Edit, Trash2, Plus } from "lucide-react"
import Image from "next/image"

export default function ReviewsPage() {
  const [reviews, setReviews] = useState([
    {
      id: 1,
      product: "Handwoven Scarf",
      artisan: "Sarah's Crafts",
      rating: 5,
      comment: "Beautiful craftsmanship! Love the colors and texture.",
      date: "2024-01-15",
      status: "Published",
    },
    {
      id: 2,
      product: "Ceramic Vase",
      artisan: "Mike's Pottery",
      rating: 4,
      comment: "Great quality, fast shipping. Very happy with purchase.",
      date: "2024-01-10",
      status: "Published",
    },
    {
      id: 3,
      product: "Leather Wallet",
      artisan: "Emma's Leather",
      rating: 5,
      comment: "Perfect gift, excellent quality and attention to detail!",
      date: "2024-01-05",
      status: "Published",
    },
  ])

  const pendingReviews = [
    { id: 1, product: "Wooden Bowl", artisan: "Tom's Woodwork", orderDate: "2024-01-20" },
    { id: 2, product: "Silver Bracelet", artisan: "Anna's Jewelry", orderDate: "2024-01-18" },
  ]

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState("")
  const [rating, setRating] = useState(0)
  const [comment, setComment] = useState("")

  const handleDeleteReview = (id: number) => {
    setReviews(reviews.filter((review) => review.id !== id))
  }

  const renderStars = (rating: number, interactive = false, onRatingChange?: (rating: number) => void) => {
    return (
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-5 w-5 ${
              star <= rating ? "text-yellow-400 fill-current" : "text-gray-300"
            } ${interactive ? "cursor-pointer hover:text-yellow-400" : ""}`}
            onClick={interactive && onRatingChange ? () => onRatingChange(star) : undefined}
          />
        ))}
      </div>
    )
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Reviews</h1>
          <p className="text-gray-600 mt-2">Manage your product reviews and feedback</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              Write Review
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Write a Review</DialogTitle>
              <DialogDescription>Share your experience with this product</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Product</Label>
                <select
                  className="w-full p-2 border rounded-md"
                  value={selectedProduct}
                  onChange={(e) => setSelectedProduct(e.target.value)}
                >
                  <option value="">Select a product</option>
                  {pendingReviews.map((item) => (
                    <option key={item.id} value={item.product}>
                      {item.product} - {item.artisan}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <Label>Rating</Label>
                <div className="mt-2">{renderStars(rating, true, setRating)}</div>
              </div>
              <div>
                <Label htmlFor="reviewComment">Your Review</Label>
                <Textarea
                  id="reviewComment"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Share your thoughts about this product..."
                  className="min-h-[100px]"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  className="flex-1"
                  onClick={() => {
                    // Add review logic here
                    setIsAddDialogOpen(false)
                    setSelectedProduct("")
                    setRating(0)
                    setComment("")
                  }}
                  disabled={!selectedProduct || rating === 0 || !comment.trim()}
                >
                  Submit Review
                </Button>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Your Reviews</CardTitle>
              <CardDescription>Reviews you've written for products</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {reviews.map((review) => (
                  <div key={review.id} className="border-b border-gray-200 pb-6 last:border-b-0">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-4">
                        <Image
                          src="/placeholder.svg"
                          alt={review.product}
                          width={60}
                          height={60}
                          className="rounded-md object-cover"
                        />
                        <div>
                          <h3 className="font-medium">{review.product}</h3>
                          <p className="text-sm text-gray-600">{review.artisan}</p>
                          <p className="text-xs text-gray-500">{review.date}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{review.status}</Badge>
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDeleteReview(review.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="mb-2">{renderStars(review.rating)}</div>
                    <p className="text-gray-700">{review.comment}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Pending Reviews</CardTitle>
              <CardDescription>Products waiting for your feedback</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingReviews.map((item) => (
                  <div key={item.id} className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3 mb-2">
                      <Image
                        src="/placeholder.svg"
                        alt={item.product}
                        width={40}
                        height={40}
                        className="rounded-md object-cover"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-sm">{item.product}</p>
                        <p className="text-xs text-gray-600">{item.artisan}</p>
                        <p className="text-xs text-gray-500">Ordered: {item.orderDate}</p>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      className="w-full"
                      onClick={() => {
                        setSelectedProduct(item.product)
                        setIsAddDialogOpen(true)
                      }}
                    >
                      Write Review
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Review Stats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">Total Reviews</span>
                  <span className="font-medium">{reviews.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Average Rating</span>
                  <span className="font-medium">
                    {(reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Pending Reviews</span>
                  <span className="font-medium">{pendingReviews.length}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
