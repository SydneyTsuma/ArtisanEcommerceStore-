import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function Home() {
  // Featured products data with updated KSH prices and descriptions
  const featuredProducts = [
    {
      id: 1,
      name: "Handwoven Basket",
      price: 2500,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Handwoven%20Basket.jpg-uwbUnw2yzGMnXQIXqImUzLyzqFecn9.jpeg",
      artisan: "Amara Crafts",
    },
    {
      id: 2,
      name: "Beaded Necklace",
      price: 1200,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Beaded%20necklace-6fNn9NVItp4zxBrEkLuluS8v9hOFzi.webp",
      artisan: "Zuri Designs",
    },
    {
      id: 3,
      name: "Telephone Wire Bowl",
      price: 3500,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Telephone-wire-bowls.jpg-AsReqTcypWH9REP0OzAY4Yy0v8vWnr.jpeg",
      artisan: "Tafari Designs",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-beige-200">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-brown-600">
                  Authentic African Artisan Crafts
                </h1>
                <p className="max-w-[600px] text-muted-foreground md:text-xl">
                  Discover unique handcrafted items directly from talented artisans across Africa.
                </p>
              </div>
              <div>
                <Link href="/auth">
                  <Button className="bg-brown-600 hover:bg-brown-700">Sign Up</Button>
                </Link>
              </div>
            </div>
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Authentic%20Africa-ZBMXuY9gv2BQh9UId81UONmni1sFUW.jpeg"
              alt="Traditional African artisan wearing a woven straw hat"
              width={500}
              height={500}
              className="mx-auto aspect-square overflow-hidden rounded-xl object-cover"
            />
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-brown-600">
                Featured Artisan Products
              </h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Each item tells a story and supports local artisans and their communities.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-8">
            {featuredProducts.map((product) => (
              <Link key={product.id} href={`/products/${product.id}`}>
                <Card className="overflow-hidden transition-all hover:shadow-lg">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={300}
                    height={300}
                    className="aspect-square object-cover w-full"
                  />
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-lg">{product.name}</h3>
                    <p className="text-sm text-muted-foreground">By {product.artisan}</p>
                    <p className="font-medium text-brown-600 mt-2">KSh {product.price.toLocaleString()}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
          <div className="flex justify-center mt-8">
            <Link href="/products">
              <Button variant="outline" className="border-brown-500 text-brown-600">
                View All Products
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-brown-500 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Join Our Community</h2>
              <p className="max-w-[900px] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Whether you're a customer looking for unique items or an artisan wanting to showcase your craft.
              </p>
            </div>
            <div>
              <Link href="/auth">
                <Button className="bg-white text-brown-600 hover:bg-beige-200">Sign Up Today</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
