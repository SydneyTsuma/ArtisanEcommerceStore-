"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { getCurrentUser, logoutUser } from "@/lib/auth-actions"

// Mock order data with updated KSH prices
const customerOrders = [
  {
    id: "ORD-001",
    date: "2023-11-15",
    total: 6000,
    status: "Delivered",
    items: [
      { id: 1, name: "Handwoven Basket", quantity: 1, price: 2500 },
      { id: 3, name: "Carved Wooden Bowl", quantity: 1, price: 3500 },
    ],
  },
  {
    id: "ORD-002",
    date: "2023-12-03",
    total: 1200,
    status: "Processing",
    items: [{ id: 2, name: "Beaded Necklace", quantity: 1, price: 1200 }],
  },
]

// Mock artisan products and orders with updated KSH prices
const artisanProducts = [
  {
    id: 1,
    name: "Handwoven Basket",
    price: 2500,
    image: "/placeholder.svg?height=100&width=100",
    stock: 5,
    sold: 12,
  },
  {
    id: 2,
    name: "Beaded Necklace",
    price: 1200,
    image: "/placeholder.svg?height=100&width=100",
    stock: 8,
    sold: 5,
  },
]

const artisanOrders = [
  {
    id: "ORD-003",
    customer: "John Doe",
    date: "2023-12-01",
    total: 2500,
    status: "Pending Approval",
    items: [{ id: 1, name: "Handwoven Basket", quantity: 1, price: 2500 }],
  },
  {
    id: "ORD-004",
    customer: "Sarah Johnson",
    date: "2023-11-28",
    total: 2400,
    status: "Shipped",
    items: [{ id: 2, name: "Beaded Necklace", quantity: 2, price: 1200 }],
  },
]

export default function ProfilePage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function loadUser() {
      try {
        const currentUser = await getCurrentUser()
        if (!currentUser) {
          router.push("/auth")
          return
        }
        setUser(currentUser)
      } catch (error) {
        console.error("Failed to load user:", error)
      } finally {
        setLoading(false)
      }
    }

    loadUser()
  }, [router])

  if (loading) {
    return (
      <div className="container py-12 text-center">
        <p>Loading profile...</p>
      </div>
    )
  }

  if (!user) {
    return null // Redirect handled in useEffect
  }

  const handleLogout = async () => {
    await logoutUser()
  }

  const approveOrder = (orderId: string) => {
    // In a real app, this would update the order status in the database
    alert(`Order ${orderId} approved for shipping`)
  }

  return (
    <div className="container py-8 md:py-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div className="flex items-center gap-4">
          <Image
            src="/placeholder.svg?height=80&width=80"
            alt="Profile"
            width={80}
            height={80}
            className="rounded-full"
          />
          <div>
            <h1 className="text-2xl font-bold text-brown-600">{user.name}</h1>
            <p className="text-muted-foreground">{user.email}</p>
          </div>
        </div>
        <Button variant="outline" className="border-brown-500 text-brown-600" onClick={handleLogout}>
          Log Out
        </Button>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          {user.role === "artisan" && <TabsTrigger value="products">My Products</TabsTrigger>}
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Profile Overview</CardTitle>
              <CardDescription>
                {user.role === "customer"
                  ? "View your recent orders and account information."
                  : "Manage your products and customer orders."}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">
                      {user.role === "customer" ? "Orders Placed" : "Products Listed"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {user.role === "customer" ? customerOrders.length : artisanProducts.length}
                    </div>
                  </CardContent>
                </Card>

                {user.role === "artisan" && (
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        KSh{" "}
                        {artisanProducts
                          .reduce((sum, product) => sum + product.price * product.sold, 0)
                          .toLocaleString()}
                      </div>
                    </CardContent>
                  </Card>
                )}

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Account Type</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold capitalize">{user.role}</div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{user.role === "customer" ? "Recent Orders" : "Recent Customer Orders"}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {(user.role === "customer" ? customerOrders : artisanOrders).slice(0, 2).map((order) => (
                  <div key={order.id} className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">{order.id}</p>
                      <p className="text-sm text-muted-foreground">
                        {order.date} • KSh {order.total.toLocaleString()}
                      </p>
                    </div>
                    <Badge
                      className={
                        order.status === "Delivered"
                          ? "bg-green-500"
                          : order.status === "Processing" || order.status === "Shipped"
                            ? "bg-blue-500"
                            : "bg-yellow-500"
                      }
                    >
                      {order.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="orders" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{user.role === "customer" ? "Your Orders" : "Customer Orders"}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {(user.role === "customer" ? customerOrders : artisanOrders).map((order) => (
                  <Card key={order.id}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-lg">{order.id}</CardTitle>
                        <Badge
                          className={
                            order.status === "Delivered"
                              ? "bg-green-500"
                              : order.status === "Processing" || order.status === "Shipped"
                                ? "bg-blue-500"
                                : "bg-yellow-500"
                          }
                        >
                          {order.status}
                        </Badge>
                      </div>
                      <CardDescription>
                        {order.date} • KSh {order.total.toLocaleString()}
                        {user.role === "artisan" && ` • ${order.customer}`}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {order.items.map((item) => (
                          <div key={item.id} className="flex justify-between">
                            <span>
                              {item.name} x {item.quantity}
                            </span>
                            <span>KSh {(item.price * item.quantity).toLocaleString()}</span>
                          </div>
                        ))}
                      </div>

                      {user.role === "artisan" && order.status === "Pending Approval" && (
                        <div className="mt-4">
                          <Button className="bg-brown-600 hover:bg-brown-700" onClick={() => approveOrder(order.id)}>
                            Approve for Shipping
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {user.role === "artisan" && (
          <TabsContent value="products" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Your Products</CardTitle>
                <Button className="bg-brown-600 hover:bg-brown-700">Add New Product</Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {artisanProducts.map((product) => (
                    <div key={product.id} className="flex items-center gap-4">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        width={80}
                        height={80}
                        className="rounded-md object-cover"
                      />
                      <div className="flex-1">
                        <h3 className="font-medium">{product.name}</h3>
                        <p className="text-sm text-muted-foreground">
                          KSh {product.price.toLocaleString()} • {product.stock} in stock • {product.sold} sold
                        </p>
                      </div>
                      <Button variant="outline" size="sm">
                        Edit
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Account Settings</CardTitle>
              <CardDescription>Manage your account settings and preferences</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Account settings functionality would be implemented here.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
