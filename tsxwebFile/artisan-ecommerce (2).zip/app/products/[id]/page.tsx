"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Minus, Plus, ShoppingCart } from "lucide-react"

// Mock product data with updated KSH prices and images
const products = [
  {
    id: 1,
    name: "Handwoven Basket",
    price: 2500,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Handwoven%20Basket.jpg-uwbUnw2yzGMnXQIXqImUzLyzqFecn9.jpeg",
    artisan: "Amara Crafts",
    artisanId: "a1",
    description:
      "This beautiful handwoven basket is crafted using traditional techniques passed down through generations. Each basket takes several days to complete and features intricate patterns unique to the region.",
    materials: ["Natural fibers", "Sisal", "Colored thread"],
    dimensions: '12" x 10" x 8"',
    inStock: 5,
  },
  {
    id: 2,
    name: "Beaded Necklace",
    price: 1200,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Beaded%20necklace-6fNn9NVItp4zxBrEkLuluS8v9hOFzi.webp",
    artisan: "Zuri Designs",
    artisanId: "a2",
    description:
      "This stunning beaded necklace is handcrafted with glass beads in vibrant colors. Inspired by traditional African designs, it makes a bold statement piece that celebrates cultural heritage.",
    materials: ["Glass beads", "Cotton thread", "Metal clasps"],
    dimensions: '18" length',
    inStock: 8,
  },
  {
    id: 3,
    name: "Telephone Wire Bowl",
    price: 3500,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Telephone-wire-bowls.jpg-AsReqTcypWH9REP0OzAY4Yy0v8vWnr.jpeg",
    artisan: "Tafari Designs",
    artisanId: "a3",
    description:
      "These exquisite telephone wire bowls are meticulously handcrafted using traditional weaving techniques. Each bowl features a unique spiral pattern with contrasting colors that showcase the artisan's skill and creativity.",
    materials: ["Recycled telephone wire", "PVC coated wire"],
    dimensions: '8" diameter x 3" height',
    inStock: 3,
  },
]

export default function ProductPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const productId = Number.parseInt(params.id)
  const product = products.find((p) => p.id === productId)

  const [quantity, setQuantity] = useState(1)

  if (!product) {
    return (
      <div className="container py-12 text-center">
        <h1 className="text-2xl font-bold text-brown-600 mb-4">Product Not Found</h1>
        <p className="mb-6">The product you're looking for doesn't exist or has been removed.</p>
        <Button onClick={() => router.push("/products")} className="bg-brown-600 hover:bg-brown-700">
          Back to Products
        </Button>
      </div>
    )
  }

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1)
    }
  }

  const increaseQuantity = () => {
    if (quantity < product.inStock) {
      setQuantity(quantity + 1)
    }
  }

  const addToCart = () => {
    // In a real app, this would add the product to the cart
    // For now, we'll just navigate to the cart page
    router.push("/cart")
  }

  return (
    <div className="container py-8 md:py-12">
      <div className="grid md:grid-cols-2 gap-8">
        {/* Product Image */}
        <div className="bg-white rounded-lg overflow-hidden">
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            width={500}
            height={500}
            className="w-full object-cover"
          />
        </div>

        {/* Product Details */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold text-brown-600">{product.name}</h1>
            <p className="text-lg font-medium text-brown-500 mt-2">KSh {product.price.toLocaleString()}</p>
            <div className="flex items-center mt-2">
              <p className="text-sm text-muted-foreground">By {product.artisan}</p>
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="font-medium">Description</h3>
            <p className="text-muted-foreground">{product.description}</p>
          </div>

          <div className="space-y-2">
            <h3 className="font-medium">Materials</h3>
            <ul className="list-disc list-inside text-muted-foreground">
              {product.materials.map((material, index) => (
                <li key={index}>{material}</li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-medium">Dimensions</h3>
            <p className="text-muted-foreground">{product.dimensions}</p>
          </div>

          <div>
            <p className="text-sm">{product.inStock > 0 ? `${product.inStock} in stock` : "Out of stock"}</p>
          </div>

          <div className="pt-4 space-y-4">
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="icon" onClick={decreaseQuantity} disabled={quantity <= 1}>
                <Minus className="h-4 w-4" />
              </Button>
              <span className="text-lg font-medium w-8 text-center">{quantity}</span>
              <Button variant="outline" size="icon" onClick={increaseQuantity} disabled={quantity >= product.inStock}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>

            <Button
              className="w-full bg-brown-600 hover:bg-brown-700"
              onClick={addToCart}
              disabled={product.inStock === 0}
            >
              <ShoppingCart className="mr-2 h-4 w-4" />
              Add to Cart
            </Button>
          </div>
        </div>
      </div>

      {/* Artisan Card */}
      <Card className="mt-12">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-6 items-center">
            <Image
              src="/placeholder.svg?height=100&width=100"
              alt={product.artisan}
              width={100}
              height={100}
              className="rounded-full"
            />
            <div>
              <h3 className="text-xl font-semibold text-brown-600">{product.artisan}</h3>
              <p className="text-muted-foreground mt-2">
                This item is handcrafted by {product.artisan}, a skilled artisan specializing in traditional crafts.
                Each piece is made with care and attention to detail, ensuring a unique and authentic product.
              </p>
              <Button
                variant="outline"
                className="mt-4 border-brown-500 text-brown-600"
                onClick={() => router.push(`/artisans/${product.artisanId}`)}
              >
                View Artisan Profile
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
