import Link from "next/link"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

// Mock product data with updated KSH prices and images
const products = [
  {
    id: 1,
    name: "Handwoven Basket",
    price: 2500,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Handwoven%20Basket.jpg-uwbUnw2yzGMnXQIXqImUzLyzqFecn9.jpeg",
    artisan: "Amara Crafts",
    category: "Home Decor",
  },
  {
    id: 2,
    name: "Beaded Necklace",
    price: 1200,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Beaded%20necklace-6fNn9NVItp4zxBrEkLuluS8v9hOFzi.webp",
    artisan: "Zuri Designs",
    category: "Jewelry",
  },
  {
    id: 3,
    name: "Telephone Wire Bowl",
    price: 3500,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Telephone-wire-bowls.jpg-AsReqTcypWH9REP0OzAY4Yy0v8vWnr.jpeg",
    artisan: "Tafari Designs",
    category: "Kitchen",
  },
  {
    id: 4,
    name: "Embroidered Pillow Cover",
    price: 1800,
    image: "/placeholder.svg?height=300&width=300",
    artisan: "Nia Textiles",
    category: "Home Decor",
  },
  {
    id: 5,
    name: "Leather Journal",
    price: 2200,
    image: "/placeholder.svg?height=300&width=300",
    artisan: "Kwame Leatherworks",
    category: "Stationery",
  },
  {
    id: 6,
    name: "Clay Pottery Set",
    price: 4500,
    image: "/placeholder.svg?height=300&width=300",
    artisan: "Makena Ceramics",
    category: "Kitchen",
  },
]

// Categories for filtering
const categories = ["All", "Home Decor", "Jewelry", "Kitchen", "Stationery"]

export default function ProductsPage() {
  return (
    <div className="container py-8 md:py-12">
      <h1 className="text-3xl font-bold text-brown-600 mb-6">Browse Artisan Products</h1>

      {/* Search and Filter */}
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input placeholder="Search products..." className="pl-10" />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category}
              variant={category === "All" ? "default" : "outline"}
              className={category === "All" ? "bg-brown-600 hover:bg-brown-700" : "border-brown-500 text-brown-600"}
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <Link key={product.id} href={`/products/${product.id}`}>
            <Card className="overflow-hidden transition-all hover:shadow-lg">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                width={300}
                height={300}
                className="aspect-square object-cover w-full"
              />
              <CardContent className="p-4">
                <h3 className="font-semibold text-lg">{product.name}</h3>
                <p className="text-sm text-muted-foreground">By {product.artisan}</p>
                <div className="flex justify-between items-center mt-2">
                  <p className="font-medium text-brown-600">KSh {product.price.toLocaleString()}</p>
                  <span className="text-xs bg-beige-200 text-brown-600 px-2 py-1 rounded-full">{product.category}</span>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}
