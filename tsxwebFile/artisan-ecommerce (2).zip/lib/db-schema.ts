// This file represents the database schema for the application
// In a real application, this would be implemented with Prisma, Drizzle, or another ORM

/*
Database Schema:

Users Table:
- id (PK)
- name
- email
- password (hashed)
- role (customer or artisan)
- createdAt
- updatedAt

Products Table:
- id (PK)
- name
- description
- price
- stock
- image
- artisanId (FK -> Users.id)
- category
- materials
- dimensions
- createdAt
- updatedAt

Orders Table:
- id (PK)
- customerId (FK -> Users.id)
- status (pending, approved, shipped, delivered)
- totalAmount
- shippingAddress
- createdAt
- updatedAt

OrderItems Table:
- id (PK)
- orderId (FK -> Orders.id)
- productId (FK -> Products.id)
- quantity
- price
- createdAt
- updatedAt

Relationships:
- User (Artisan) has many Products
- User (Customer) has many Orders
- Order belongs to User (Customer)
- Order has many OrderItems
- OrderItem belongs to Order
- OrderItem belongs to Product
- Product belongs to User (Artisan)
*/

// Example of how this would be implemented with Prisma schema
/*
model User {
  id        String    @id @default(cuid())
  name      String
  email     String    @unique
  password  String
  role      String    // "customer" or "artisan"
  products  Product[] // Only for artisans
  orders    Order[]   // Only for customers
  createdAt DateTime  @default(now())
  updatedAt DateTime  @updatedAt
}

model Product {
  id          String      @id @default(cuid())
  name        String
  description String
  price       Float
  stock       Int
  image       String
  artisan     User        @relation(fields: [artisanId], references: [id])
  artisanId   String
  category    String
  materials   String[]
  dimensions  String?
  orderItems  OrderItem[]
  createdAt   DateTime    @default(now())
  updatedAt   DateTime    @updatedAt
}

model Order {
  id              String      @id @default(cuid())
  customer        User        @relation(fields: [customerId], references: [id])
  customerId      String
  status          String      // "pending", "approved", "shipped", "delivered"
  totalAmount     Float
  shippingAddress String
  orderItems      OrderItem[]
  createdAt       DateTime    @default(now())
  updatedAt       DateTime    @updatedAt
}

model OrderItem {
  id        String   @id @default(cuid())
  order     Order    @relation(fields: [orderId], references: [id])
  orderId   String
  product   Product  @relation(fields: [productId], references: [id])
  productId String
  quantity  Int
  price     Float
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}
*/
