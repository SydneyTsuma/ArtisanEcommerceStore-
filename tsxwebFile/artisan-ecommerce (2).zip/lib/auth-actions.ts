"use server"

import { cookies } from "next/headers"
import { redirect } from "next/navigation"

// In a real app, you would use a proper authentication system
// This is a simplified mock implementation

type User = {
  id: string
  name: string
  email: string
  role: "customer" | "artisan"
}

type CreateUserParams = {
  name: string
  email: string
  password: string
  role: string
}

type LoginParams = {
  email: string
  password: string
}

// Mock user database
const MOCK_USERS: User[] = [
  {
    id: "1",
    name: "John Doe",
    email: "john@example.com",
    role: "customer",
  },
  {
    id: "2",
    name: "Jane Smith",
    email: "jane@example.com",
    role: "artisan",
  },
]

export async function createUser(params: CreateUserParams): Promise<User> {
  // In a real app, you would hash the password and store in a database
  const newUser: User = {
    id: Math.random().toString(36).substring(2, 9),
    name: params.name,
    email: params.email,
    role: params.role as "customer" | "artisan",
  }

  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Set a cookie to simulate authentication
  cookies().set("user_id", newUser.id, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 7, // 1 week
    path: "/",
  })

  return newUser
}

export async function loginUser(params: LoginParams): Promise<User> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // In a real app, you would verify credentials against a database
  const user = MOCK_USERS.find((u) => u.email === params.email)

  if (!user) {
    throw new Error("Invalid credentials")
  }

  // Set a cookie to simulate authentication
  cookies().set("user_id", user.id, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 7, // 1 week
    path: "/",
  })

  return user
}

export async function getCurrentUser(): Promise<User | null> {
  const userId = cookies().get("user_id")?.value

  if (!userId) {
    return null
  }

  // In a real app, you would fetch the user from a database
  const user = MOCK_USERS.find((u) => u.id === userId)

  return user || null
}

export async function logoutUser(): Promise<void> {
  cookies().delete("user_id")
  redirect("/")
}
